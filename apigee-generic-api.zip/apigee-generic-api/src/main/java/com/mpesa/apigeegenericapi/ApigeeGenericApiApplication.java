package com.mpesa.apigeegenericapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApigeeGenericApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApigeeGenericApiApplication.class, args);
	}

}
