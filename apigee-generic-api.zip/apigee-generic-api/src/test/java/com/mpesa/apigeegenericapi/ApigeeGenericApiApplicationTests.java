package com.mpesa.apigeegenericapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApigeeGenericApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
